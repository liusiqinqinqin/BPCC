 load Cost_Sa_2.mat
 load Cost_BP.mat
 load Cost_Sa_1.mat
%  Cost_2 = Cost
  %Cost_1 = Cost_all(1:50);
%  Cost_2 = Cost_all(1:37)
 plot([1:2:50],Cost_BP(1:2:50),[1:2:50],Cost_Sa_1(1:2:50),'g',[1:2:50],Cost_Sa_2(1:2:50),'r')