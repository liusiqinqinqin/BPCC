function [nn,cost3] = Ae_train(nn,patches)  
%% train AE
% numhid :��ʾ������ڵ���
% ƫ��b1���ɽ����õ��ģ����඼�����ݶ��½����õ�

beta                   = 2;
sparsityParam          = 0.05;

%numvisiable = size(patches,1);
%sizes = [numvisiable,numhid,numvisiable];
% [nn] = Ae_initial(sizes);

% ÿһ��ѵ��������
numpatches = size(patches,2);
nn.x = patches;

output_2 = sigm(nn.W{1}*patches + repmat(nn.b{1},1,numpatches));
nn.y = output_2;
output_3 = sigm(nn.W{2}*output_2 + repmat(nn.b{2},1,numpatches));

%ϡ����
Rho = sum(output_2,2)/numpatches;
Penalty = -sparsityParam./Rho + (1-sparsityParam)./(1-Rho);

Delta3 = (output_3 - patches).*output_3.*(1 - output_3);
Delta2 = (nn.W{2}'*Delta3 + beta*repmat(Penalty,1,numpatches)).*output_2.*(1 - output_2);

 cost1 = sum(sum((output_3 - patches).^2))/numpatches/2 + (sum(sum((nn.W{1}.^2))) + sum(sum((nn.W{2}.^2))))*nn.l/2;
% %cost = cost/numpatches;
 cost2 = beta*sum(sparsityParam*log(sparsityParam./Rho)+(1-sparsityParam)*log((1-sparsityParam)./(1-Rho)));
%

 cost3 = cost1 + cost2;
% Ȩֵ����
W1grad = nn.l.*nn.W{1} + Delta2*patches'/numpatches;
W2grad = nn.l.*nn.W{2} + Delta3*output_2'/numpatches;

nn.W{1} = nn.W{1} - nn.learning*W1grad;
nn.W{2} = nn.W{2} - nn.learning*W2grad;

% ƫ����� 
% b1 = ���㷨����
nn.b{1} = nn.b{1} - nn.learning*sum(Delta2,2)/numpatches ;
nn.b{2} = nn.b{2} - nn.learning*sum(Delta3,2)/numpatches  ;

 nn.cost = nn.cost + cost3;

% 
% EPSILON=0.0001;
% for i=1:size(theta)
%     theta_plus=theta;
%     theta_minu=theta;
%     theta_plus(i)=theta_plus(i)+EPSILON;
%     theta_minu(i)=theta_minu(i)-EPSILON;
%     numgrad(i)=(J(theta_plus)-J(theta_minu))/(2*EPSILON);
% end

end