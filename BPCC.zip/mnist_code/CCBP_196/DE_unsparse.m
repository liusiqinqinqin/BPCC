 function [best_vector_1,value_min] = DE_unsparse(nn,sizes,train_x,train_y,pop_1,sub_index)

% nn ΪAE��һЩ����
% pop ��ʼ������Ⱥ
% pre ����Ԫ�أ���һ��Ϊ�ɼ��ڵ���ڶ���Ϊ������Ľڵ���
number_batch = 2000;
m = size(train_x,2);
kk = randperm(m);
x = train_x(:,kk(1:number_batch));
y = train_y(:,kk(1:number_batch));
%t0 = cputime;
%��ֽ��㷨����?%F0�Ǳ����� %Gm ��������
[w_d,N] = size(pop_1);
F0 = 0.5;
Np = N;
CR = 0.9;  
%D = nu


value = zeros(1,Np);
Gm = 50;
Gmin = zeros(1,Gm);
XG_next_1 = zeros(w_d,Np);

XG_next = zeros(w_d,Np);

G = 1;
%%%%%%%%%%%%%%%%%%%%%%%%----�������?---%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
while (G < Gm+1)
for i = 1:Np
    %����j,k,p�����ͬ����?    
    a = 1;
    b = Np;
    dx = randperm(b-a+1) + a - 1;
    j = dx(1);
    k = dx(2);
    p = dx(3);
    %Ҫ��֤��i��ͬ
    if j == i
        j  = dx(4);
        else if k == i
             k = dx(4);
            else if p == i
                   p = dx(4);
                end
            end
     end
%% 变异操作
    suanzi = exp(1-Gm/(Gm + 1-G));
    F = F0*2.^suanzi;
    son_1 = pop_1(:,p) + F*(pop_1(:,j) - pop_1(:,k));

    XG_next_1(:,i) = son_1;
   
        
end
  
%% 交叉操作     
    XG_next_2 = XG_next_1;
    TT = find(rand(a,Np)>CR);  
    XG_next_2(TT) = pop_1(TT);
    
  
 %% 选择操作


for i = 1:Np
    
    a = fun_unsparse(x,y,nn,sizes,XG_next_2(:,i),sub_index);
    b = fun_unsparse(x,y,nn,sizes,pop_1(:,i),sub_index);
    %b = fun_unsparse(train_x,pop_1(:,:,i),pop_2(:,:,i),kk);

    if a > b
        %iii = iii + 1 
        XG_next(:,i) = XG_next_2(:,i); 
        
        value(i) = a;
    else
       %jjj = jjj + 1
        XG_next(:,i) = pop_1(:,i);
      
        value(i) = b;
    end
end
    [value_min,num_min] = min(value);
    Gmin(1,G) = value_min;
   
    pop_1 = XG_next;
    G = G+1;
   
end
    num_min
    best_vector_1 = pop_1(:,num_min);
    
    
  
end
 

