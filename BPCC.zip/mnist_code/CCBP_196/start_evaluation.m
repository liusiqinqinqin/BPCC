clc
clear
load mnist_uint8.mat;
%load nn3;

train_x = double(train_x)/255;
test_x  = double(test_x)/255;
train_y = double(train_y);
test_y  = double(test_y);
%% �?��训练分类�?
batchsize = 100;

numinput = 784;
numhid_1 = 300;
numhid_2 = 100;
numoutput = 10;
m = size(train_x,1); 
sizes = [numinput,numhid_1,numhid_2,numoutput]; 

numbatches = m/batchsize;



numepochs = 25; 



load intial


Cost_evaluation20 = zeros(30,1);
    
iter = 3;    
for k = 1:numepochs
    
   if(k ~= 25)
       k
       % err = cal_err( test_x,test_y,nn_c )
       cost = 0;
       kk = randperm(m);
      for j = 1:100

        %nn_c.l  = nn_c.l/k;
         %kk(1:batchsize)
         batch_x = train_x(kk((j-1)*batchsize+1:batchsize+batchsize*(j-1)), :);
         batch_y = train_y(kk((j-1)*batchsize+1:batchsize+batchsize*(j-1)), :);

         [nn_c] = Bp_train(nn_c,batch_x',batch_y');
         cost = cost + nn_c.cost;
      end
     nn_d = nn_c;   
      
   else
       
       for hh = 1:30
           [cost_bpccde,nn_e] = saCCDE_all( train_x,train_y,nn_d,sizes,iter);
           Cost_evaluation20(hh,1) = cost_bpccde;

       end
   end


end

save Cost_evaluation20 Cost_evaluation20



%% 使用测试样本来验证训练的效果
% num = size(test_x,1);        
% [output] = classify(nn_c,test_x');  % 得到神经网络预测的结�?
% [A,max_num] = max(output);
% [m,n] = size(output);
% output_1 = zeros(m,n);
% 
% for i = 1:n
%     output_1(max_num(i),i) = 1;
% end
% 
% error = sum(abs(test_y - output_1'),2);
% accuracy = max(size(find(error == 0)))/num;