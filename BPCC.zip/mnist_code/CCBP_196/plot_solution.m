function plot_solution (F)
%% 画出目标函数值的分布
plot(F(:,1),F(:,2),'.');
end