function [t] = plot_sparse(nn,b,numpatchs)
%% 画出隐含层输出的稀疏图

    y = sigm(nn.y + repmat(b,1,numpatchs));
    x = [1:196];
    y = sum(y,2)/numpatchs;
   
    y1 = y - sum(y)/196;
    t = find(y1>0);
    stem(x,y,'marker','none');
end