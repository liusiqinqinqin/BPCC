function [ maturity_value] = get_maturity(x, nn, sizes,index)
    
    
    alph = 0.3;
    m_ratio = 0.3;
    [m,~,~] = cal_maturity(x, nn, sizes, alph, m_ratio);
    
    maturity_value = m(index);


end