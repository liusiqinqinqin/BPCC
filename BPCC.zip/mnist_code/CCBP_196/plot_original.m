load mnist_uint8.mat;

%data_1 = trans_data( data ); 

%train_x = double(reshape(data_1,28*28,3,10000));
kk = randperm(60000);

data = train_x(kk(1:100),:);
data = double(data);

% data1 = ones(1024,100);
% data2 = ones(1024,100);
% data3 = ones(1024,100);
% for i = 1:100
%     data1(:,i) = train_x(:,1,i);
%     data2(:,i) = train_x(:,2,i);
%     data3(:,i) = train_x(:,3,i);
% end


array1 = display_network(data');

% array1 = display_network(data1);
% figure
% array2 = display_network(data2);
% figure
% array3 = display_network(data3);
% array = zeros(331,331,3);
% array(:,:,1) = array1;
% array(:,:,2) = array2;
% array(:,:,3) = array3;
% figure
% h=imagesc(array1,'EraseMode','none',[-1 1]);
% imshow(array)
