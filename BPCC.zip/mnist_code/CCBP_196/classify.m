function [ output_3 ] = classify(nn,data)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

numpatches = size(data,2);

output_1 = sigm(nn.W{1}*data + repmat(nn.b{1},1,numpatches));

output_2 = sigm(nn.W{2}*output_1 + repmat(nn.b{2},1,numpatches));

output_3 = sigm(nn.W{3}*output_2 + repmat(nn.b{3},1,numpatches));

end

