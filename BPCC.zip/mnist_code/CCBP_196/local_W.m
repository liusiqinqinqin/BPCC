clc
clear
load mnist_uint8.mat;
train_x = double(train_x)/255;
test_x  = double(test_x)/255;
train_y = double(train_y);
test_y  = double(test_y);
load nn;
N = 100;     
sizes = [784,300,100,10];
%Sub_incode = [1:1];
%num_v = size(nn.W{1},2); 
%num_sub = max(size(Sub_incode));
nn_ori = nn;
Cost_DE = zeros(10,1);
cost = cal_cost(train_x,train_y,nn)

h = 0;
for t = 3:3                      %����Ȩ��
   i = 1;
    while (i < sizes(t+1)+1)
        
        h = h + 1;
        GG = i
        %sub_incode = Sub_incode(i);
        num_v = sizes(t);
        W = reshape(nn.W{t}(i,:),num_v,1);

        pop_1 = initial_pop(W,N);
        [best_vector_1,value_min] = DE_unsparse(nn,train_x,train_y,pop_1,i,t);

        W_opt = reshape(best_vector_1,1,num_v);

        nn.W{t}(i,:) = W_opt;
        cost1 = cal_cost(train_x,train_y,nn);
        Cost_DE(h,1) = cost1; 
         i = i + 1;
        if(cost1 < cost)  

            TTTT = 1
            nn_ori = nn;
            cost = cost1
        else
            nn = nn_ori;

        end

    end
    %a = ['nn_opt' num2str(t)];
   
end

nn_de = nn;
save nn_de nn_de
save Cost_DE Cost_DE
% nn_opt1 = nn;
% save nn_opt1 nn_opt1


