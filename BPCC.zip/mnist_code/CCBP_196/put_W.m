function [ nn ] = put_W(nn,sizes,index,w_b)
    
    layer_number = 1;
    
    
    for i = 1:nn.number_layer
       if (index < sizes(i+1)) || (index == sizes(i+1))
            nn.W{layer_number}(index,:) = w_b(1:end-1);
            nn.b{layer_number}(index) = w_b(end);
       else
           index = index - sizes(i+1);
       end       
    end


end