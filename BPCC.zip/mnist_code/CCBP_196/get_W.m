function [ w_b ] = get_W(nn,sizes,index)
    
    layer_number = 1;
    
    
    for i = 1:nn.number_layer
       if (index < sizes(i+1)) || (index == sizes(i+1))
            w = nn.W{layer_number}(index,:);
            b = nn.b{layer_number}(index);
       else
           index = index - sizes(i+1);
       end       
    end
    w_b = zeros(length(w)+1,1);
    w_b(1:length(w)) = w;
    w_b(end) = b;


end