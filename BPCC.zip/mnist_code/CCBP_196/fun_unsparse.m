function f_n = fun_unsparse(train_x,train_y,nn, sizes,indival,sub_index)
% sub_incode是一个一维数组，存放的是优化的特征的行数
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%TT = nn.W{1};
nn_w = put_W(nn,sizes,sub_index,indival);
%num_v = 784;
%n = max(size(sub_incode));


thert = 0.0001;
c = cal_cost(train_x,train_y,nn_w);
m = get_maturity(train_x,nn_w,sizes,sub_index);
f_n = 1/c + thert*m;
%
%cost1 = sum(sum((output_3 - y').^2))/numpatches/2*1000;

end

