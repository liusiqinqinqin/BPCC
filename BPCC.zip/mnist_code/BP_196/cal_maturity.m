 function [subtask_m, s_m, subtask_index ] = cal_maturity(x, nn, sizes, alph, m_ratio)
    
    number_hidden = sum(sizes(2:end));
    split_number = 10;
   
    b_size = size(x,2)/split_number;
    subtask_m = zeros(number_hidden,1);
    sizes(1) = 0;
   
    
    for bat = 1:10    
        x_b = x(:,(bat-1)*b_size+1:bat*b_size);
        for i = 1 : nn.number_layer
            
            output{i} = sigm(nn.W{i}*x_b + repmat(nn.b{i},1,b_size));
            x_b = output{i};
           
            subtask_m(sum(sizes(1:i))+1:sum(sizes(1:i+1))) = subtask_m(sum(sizes(1:i))+1:sum(sizes(1:i+1))) + g_f(output{i}, alph);
        end     
    end
    
    [s_m, s_index] = sort(subtask_m);
    subtask_index = s_index(1:round(number_hidden*m_ratio));
 
    function [w] = g_f(T, alph)
        w = sum((T<alph) | T>(1-alph),2);
    end
    
 
 end
 
 