clc
clear
load mnist_uint8.mat;
train_x = double(train_x)/255;
test_x  = double(test_x)/255;
train_y = double(train_y);
test_y  = double(test_y);
load nn2;


num = size(test_x,1);        
[output] = classify(nn,test_x');  % 得到神经网络预测的结�?
[A,max_num] = max(output);
[m,n] = size(output);
output_1 = zeros(m,n);

for i = 1:n
    output_1(max_num(i),i) = 1;
end

error = sum(abs(test_y - output_1'),2);
accuracy = max(size(find(error == 0)))/num;