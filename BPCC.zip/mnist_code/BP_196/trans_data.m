function [ data_new ] = trans_data( data )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
[m,n] = size(data);
data_new = zeros(32,32,3,m);

data_new(:,:,1,:) = double(reshape(data(:,1:n/3)',32,32,1,m))/255;
data_new(:,:,2,:) = double(reshape(data(:,n/3+1:n*2/3)',32,32,1,m))/255;
data_new(:,:,3,:) = double(reshape(data(:,n*2/3+1:n)',32,32,1,m))/255;


end

