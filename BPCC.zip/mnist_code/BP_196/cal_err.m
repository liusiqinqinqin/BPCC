function [ err ] = cal_err( test_x,test_y,nn )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


%test_x  = double(test_x)/255;

%test_y  = double(test_y);



num = size(test_x,1);        
[output] = classify(nn,test_x');  % 得到神经网络预测的结�?
[A,max_num] = max(output);
[m,n] = size(output);
output_1 = zeros(m,n);

for i = 1:n
    output_1(max_num(i),i) = 1;
end

error = sum(abs(test_y - output_1'),2);
accuracy = max(size(find(error == 0)))/num;
err = 1 - accuracy;

end

