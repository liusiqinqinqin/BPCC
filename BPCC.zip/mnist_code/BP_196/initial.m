function [nn] = initial(architecture)
%% initial AE parameter
% input is invisible and hidden numbers 

nn.size                = architecture;
nn.number_layer        = numel(nn.size) - 1; 
%nn.activation_function = 'tanh_opt';
%nn.learning            = 2;
nn.ll                  = 2;
nn.l                   = 0.00002;
nn.l2                  = 0.000001;
nn.cost                = 0;

% 初始化权重和偏差

for i = 2:nn.number_layer+1
    
    nn.W{i-1} = (rand(nn.size(i), nn.size(i - 1)) - 0.5) * 2 * 4 * sqrt(6 / (nn.size(i) + nn.size(i - 1)));  
    nn.b{i-1} = (rand(nn.size(i),1) - 0.5)*2;
    
end

end