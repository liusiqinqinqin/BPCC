function [ total_sum ] = cal_W_2(nn)

    total_sum = 0;
    for i=1:nn.number_layer
        total_sum = total_sum + sum(sum(nn.W{i}.*nn.W{i}));
    end
    
end