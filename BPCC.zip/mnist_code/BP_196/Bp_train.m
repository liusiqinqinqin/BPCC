function [ nn ] = Bp_train(nn,pathes_x,pathes_y)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


numpatches = size(pathes_x,2);

input_x = pathes_x;
%size(nn.W{1})
%size(input_x)
%size(repmat(nn.b{1},1,numpatches))
for i = 1:nn.number_layer

    output{i} = sigm(nn.W{i}*input_x + repmat(nn.b{i},1,numpatches));
    input_x = output{i};
end

Delta{nn.number_layer} = (output{nn.number_layer} - pathes_y).*output{nn.number_layer}.*(1 - output{nn.number_layer});
for i = nn.number_layer-1:-1:1    
    Delta{i} = (nn.W{i+1}'*Delta{i+1}).*output{i}.*(1 - output{i});
end

Wgrad{1} =  nn.l.*nn.W{1} + Delta{1}*pathes_x'/numpatches;
for i = 2:nn.number_layer
    Wgrad{i} = nn.l.*nn.W{i} + Delta{i}*output{i-1}'/numpatches;
end

for i = 1:nn.number_layer
    nn.W{i} = nn.W{i} - nn.ll*Wgrad{i};
    nn.b{i} = nn.b{i} - nn.ll*sum(Delta{i},2)/numpatches;
end

end

