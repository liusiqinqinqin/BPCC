function [ cost1 ] = cal_cost(train_x,train_y,nn)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

N = size(train_x,2);
%size(nn.W{i})
%size(x)
%size(repmat(nn.b{i},1,N))

%numpatches = m;
x = train_x;

for i = 1:nn.number_layer 
    
    x = sigm(nn.W{i}*x + repmat(nn.b{i},1,N));
   
    %%output_2 = sigm(nn.W{2}*output_1 + repmat(nn.b{2},1,numpatches));
    %%output_3 = sigm(nn.W{3}*output_2 + repmat(nn.b{3},1,numpatches));
end
l2_value = cal_W_2(nn);
cost1 = sum(sum((x - train_y).^2))/N/2 + nn.l2*l2_value;


end

