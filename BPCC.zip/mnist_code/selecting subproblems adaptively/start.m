%clc
%clear
load ..\..\mnist\mnist_uint8.mat;
%load nn3;

train_x = double(train_x)/255;
test_x  = double(test_x')/255;
train_y = double(train_y);
test_y  = double(test_y);
%% �?��训练分类�?
batchsize = 100;

numinput = 784;
numhid_1 = 300;
numhid_2 = 100;
numoutput = 10;
m = size(train_x,1); 
sizes = [numinput,numhid_1,numhid_2,numoutput]; 

numbatches = m/batchsize;

numepochs = 50; 
iteration = 100;

Threshold = 0.01;


alph = 0.3;
m_ratio = 0.3;


nn = initial(sizes);
load nn_1
nn = nn_1;
nn.number_layer = 3;


tic

[~,~,subtask_index_need] = cal_maturity(train_x', nn, sizes, alph, m_ratio);
[nn,Cost_all] = saCCDE_all(train_x', train_y', nn, sizes, subtask_index_need);


toc
x = [1:len(subtask_index_need)];

plot(x,Cost_all )

