function  [nn,Cost_DE ] = saCCDE_all( train_x,train_y,nn,sizes,subtask_index_need)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

N_P = 100;
nn_ori = nn;
%Sub_incode = [1:1];
%num_v = size(nn.W{1},2); 
%num_sub = max(size(Sub_incode));
task_number = length(subtask_index_need);

cost_last = cal_cost(train_x,train_y,nn_ori);

Cost_DE = zeros(task_number,1);


for t = 1:task_number                      %����Ȩ��        
    h = 'the number of subtask is'
    t
    %sub_incode = Sub_incode(i);
    w_b = get_W(nn_ori,sizes,subtask_index_need(t));

    pop_1 = initial_pop(w_b,N_P);
    [best_vector_1] = DE_unsparse(nn_ori,sizes,train_x,train_y,pop_1,subtask_index_need(t));

  
    [ nn_de ] = put_W(nn_ori,sizes,subtask_index_need(t),best_vector_1);

    Cost_de = cal_cost(train_x,train_y,nn_de)
    
    if(Cost_de < cost_last)  

        TTTT = 1
        nn = nn_de;
        cost_last = Cost_de;
        Cost_DE(t,1) = Cost_de;
        nn_ori = nn;
    else
        Cost_DE(t,1) = cost_last;
        nn_ori = nn;
    end

end


% nn_opt1 = nn;
% save nn_opt1 nn_opt1







end

