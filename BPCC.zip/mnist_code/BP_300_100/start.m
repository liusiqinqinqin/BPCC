%clc
%clear
load ..\..\mnist\mnist_uint8.mat;
%load nn3;

train_x = double(train_x)/255;
test_x  = double(test_x')/255;
train_y = double(train_y);
test_y  = double(test_y);
%% �?��训练分类�?
batchsize = 100;

numinput = 784;
numhid_1 = 300;
numhid_2 = 100;
numoutput = 10;
m = size(train_x,1); 
sizes = [numinput,numhid_1,numhid_2,numoutput]; 

numbatches = m/batchsize;

numepochs = 50; 
iteration = 100;


nn = initial(sizes);

%load intial
Cost_all = zeros(numepochs,1);
Cost_index = zeros(numepochs,1);  % when the value = 0, the cost is BP, otherwise the cost is CC  

iter_index = 1;
%iter{iter_index} = 1; 

subtask_number = sum(sizes(2:end));
cost_last = 0;
tic
for k = 1:numepochs    

    k 
    kk = randperm(m);
    
    x = train_x(kk(1:iteration*batchsize),:);
    y = train_y(kk(1:iteration*batchsize),:);
    
    
    for j = 1:100

        %nn_c.l  = nn_c.l/k;
        %kk(1:batchsize)
        batch_x = x((j-1)*batchsize+1:batchsize+batchsize*(j-1), :);
        batch_y = y((j-1)*batchsize+1:batchsize+batchsize*(j-1), :);
        [nn] = Bp_train(nn,batch_x',batch_y');
        %cost = cost + nn_c.cost;
   end
       cost = cal_cost(x', y', nn)
       
        Cost_all(k,1) = cost;
      

end

toc
x = [1:numepochs];

plot(x,Cost_all)

num = size(train_x,1);        
[output] = classify(nn,train_x');  % 得到神经网络预测的结�?
[A,max_num] = max(output);
[m,n] = size(output);
output_1 = zeros(m,n);

for i = 1:n
    output_1(max_num(i),i) = 1;
end

error = sum(abs(train_y - output_1'),2);
accuracy_train = max(size(find(error == 0)))/num



num = size(test_x,2);        
[output] = classify(nn,test_x);  % 得到神经网络预测的结�?
[A,max_num] = max(output);
[m,n] = size(output);
output_1 = zeros(m,n);

for i = 1:n
    output_1(max_num(i),i) = 1;
end

error = sum(abs(test_y - output_1'),2);
accuracy_test = max(size(find(error == 0)))/num
